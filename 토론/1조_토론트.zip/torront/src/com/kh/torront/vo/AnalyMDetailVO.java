package com.kh.torront.vo;

public class AnalyMDetailVO {
	
	private String omsg;
	private String indate;
	private String intime;
	private String email;
	
	public String getIndate() {
		return indate;
	}
	public void setIndate(String indate) {
		this.indate = indate;
	}
	public String getIntime() {
		return intime;
	}
	public void setIntime(String intime) {
		this.intime = intime;
	}
	public String getOmsg() {
		return omsg;
	}
	public void setOmsg(String omsg) {
		this.omsg = omsg;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
