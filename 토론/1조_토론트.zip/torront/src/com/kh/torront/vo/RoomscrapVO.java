package com.kh.torront.vo;

public class RoomscrapVO {
	
	private String sno;
	private String surl;
	
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSurl() {
		return surl;
	}
	public void setSurl(String surl) {
		this.surl = surl;
	}
	
}
