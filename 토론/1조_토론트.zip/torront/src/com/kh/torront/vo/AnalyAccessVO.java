package com.kh.torront.vo;

public class AnalyAccessVO {
	
	private String browser;

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}
	
}
