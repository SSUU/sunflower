package com.kh.torront.vo;

public class MemVO {
	
	private String mno;
	private String memail;
	private String mpw;
	private String mname;
	private String mnic;
	private String mdate;
	private String mgender;
	private String mfbuse;
	private String odate;
	private String otype;
	
	public String getMno() {
		return mno;
	}
	public void setMno(String mno) {
		this.mno = mno;
	}
	public String getOdate() {
		return odate;
	}
	public void setOdate(String odate) {
		this.odate = odate;
	}
	public String getOtype() {
		return otype;
	}
	public void setOtype(String otype) {
		this.otype = otype;
	}
	public String getOmsg() {
		return omsg;
	}
	public void setOmsg(String omsg) {
		this.omsg = omsg;
	}
	private String omsg;
	
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getMpw() {
		return mpw;
	}
	public void setMpw(String mpw) {
		this.mpw = mpw;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getMnic() {
		return mnic;
	}
	public void setMnic(String mnic) {
		this.mnic = mnic;
	}
	public String getMdate() {
		return mdate;
	}
	public void setMdate(String mdate) {
		this.mdate = mdate;
	}
	public String getMgender() {
		return mgender;
	}
	public void setMgender(String mgender) {
		this.mgender = mgender;
	}
	public String getMfbuse() {
		return mfbuse;
	}
	public void setMfbuse(String mfbuse) {
		this.mfbuse = mfbuse;
	}
	
}

