package com.kh.torront.vo;

public class MemberSignupCnt {
	
	private int preCnt = 0;
	private int toCnt = 0;
	private int allCnt = 0;
	private int outCnt = 0;
	
	public int getPreCnt() {
		return preCnt;
	}
	public void setPreCnt(int preCnt) {
		this.preCnt = preCnt;
	}
	public int getToCnt() {
		return toCnt;
	}
	public void setToCnt(int toCnt) {
		this.toCnt = toCnt;
	}
	public int getAllCnt() {
		return allCnt;
	}
	public void setAllCnt(int allCnt) {
		this.allCnt = allCnt;
	}
	public int getOutCnt() {
		return outCnt;
	}
	public void setOutCnt(int outCnt) {
		this.outCnt = outCnt;
	}
	
}
