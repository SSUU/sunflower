package com.kh.torront.vo;

public class AnalyDateLogVO {
	private String adlno;
	private String adlindate;
	private String adlintime;
	private String pno;
	
	public String getAdlno() {
		return adlno;
	}
	public void setAdlno(String adlno) {
		this.adlno = adlno;
	}
	public String getAdlindate() {
		return adlindate;
	}
	public void setAdlindate(String adlindate) {
		this.adlindate = adlindate;
	}
	public String getAdlintime() {
		return adlintime;
	}
	public void setAdlintime(String adlintime) {
		this.adlintime = adlintime;
	}
	public String getPno() {
		return pno;
	}
	public void setPno(String pno) {
		this.pno = pno;
	}
	
}
