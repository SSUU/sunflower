package com.kh.torront.vo;

public class RoomDetailVO {
	
	private String tno;
	private String tsub;
	private String tcon;
	private String tdate;
	private String tfinish;
	private String memail;
	
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getTsub() {
		return tsub;
	}
	public void setTsub(String tsub) {
		this.tsub = tsub;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getTfinish() {
		return tfinish;
	}
	public void setTfinish(String tfinish) {
		this.tfinish = tfinish;
	}
	public String getTcon() {
		return tcon;
	}
	public void setTcon(String tcon) {
		this.tcon = tcon;
	}
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	
}
