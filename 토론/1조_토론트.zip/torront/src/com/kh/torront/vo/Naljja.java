package com.kh.torront.vo;

public class Naljja {
	private String nalja;
	private String tfinish;
	
	
	public String getNalja() {
		return nalja;
	}
	public void setNalja(String nalja) {
		this.nalja = nalja;
	}
	public String getTfinish() {
		return tfinish;
	}
	public void setTfinish(String tfinish) {
		this.tfinish = tfinish;
	}
	
}
