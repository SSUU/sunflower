package com.kh.torront.vo;

public class AnalyTorronVoteVO {
	
	private String no;
	private String allCnt;	
	private String voteCnt;	
	private String reportCnt;
	
	public String getNo() {
		return no;
	}
	public void setNo(String no) {
		this.no = no;
	}
	public String getAllCnt() {
		return allCnt;
	}
	public void setAllCnt(String allCnt) {
		this.allCnt = allCnt;
	}
	public String getVoteCnt() {
		return voteCnt;
	}
	public void setVoteCnt(String voteCnt) {
		this.voteCnt = voteCnt;
	}
	public String getReportCnt() {
		return reportCnt;
	}
	public void setReportCnt(String reportCnt) {
		this.reportCnt = reportCnt;
	}
	
}
