package com.kh.torront.vo;

public class ReportDatgle {

	private String tno;
	private String tdatcon;
	private String tsub;
	private String date;
	
	public String getTsub() {
		return tsub;
	}
	public void setTsub(String tsub) {
		this.tsub = tsub;
	}
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getTdatcon() {
		return tdatcon;
	}
	public void setTdatcon(String tdatcon) {
		this.tdatcon = tdatcon;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
}