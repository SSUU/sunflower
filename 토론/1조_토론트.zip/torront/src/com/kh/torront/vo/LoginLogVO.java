package com.kh.torront.vo;

public class LoginLogVO {

	private String malno;
	private String mno;
	private String malindate;
	private String malintime;
	private String malodate;
	private String malotime;
	private String mallocal;
	private String malbrowser;
	
	public String getMalno() {
		return malno;
	}
	public void setMalno(String malno) {
		this.malno = malno;
	}
	public String getMno() {
		return mno;
	}
	public void setMno(String mno) {
		this.mno = mno;
	}
	public String getMalindate() {
		return malindate;
	}
	public void setMalindate(String malindate) {
		this.malindate = malindate;
	}
	public String getMalintime() {
		return malintime;
	}
	public void setMalintime(String malintime) {
		this.malintime = malintime;
	}
	public String getMalodate() {
		return malodate;
	}
	public void setMalodate(String malodate) {
		this.malodate = malodate;
	}
	public String getMalotime() {
		return malotime;
	}
	public void setMalotime(String malotime) {
		this.malotime = malotime;
	}
	public String getMallocal() {
		return mallocal;
	}
	public void setMallocal(String mallocal) {
		this.mallocal = mallocal;
	}
	public String getMalbrowser() {
		return malbrowser;
	}
	public void setMalbrowser(String malbrowser) {
		this.malbrowser = malbrowser;
	}
	
}
