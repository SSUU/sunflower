package com.kh.torront.vo;

public class RoomDatHistoryVO {
	
	private String memail;
	private String mnic;
	private String tdatno;
	private String tdatcon;
	private String tdate;
	
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getTdatno() {
		return tdatno;
	}
	public void setTdatno(String tdatno) {
		this.tdatno = tdatno;
	}
	public String getTdatcon() {
		return tdatcon;
	}
	public void setTdatcon(String tdatcon) {
		this.tdatcon = tdatcon;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getMnic() {
		return mnic;
	}
	public void setMnic(String mnic) {
		this.mnic = mnic;
	}
	
}
