package com.kh.torront.vo;

public class ContentlistVO {
	
	private String tno;	
	private String mno;
	private String tsub;
	private String tcon;
	private String tdate;
	private String tfinish;
	private String tcnt;
	private String cateno;
	private String ting;
	private String tsingocnt;
	
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getMno() {
		return mno;
	}
	public void setMno(String mno) {
		this.mno = mno;
	}
	public String getTsub() {
		return tsub;
	}
	public void setTsub(String tsub) {
		this.tsub = tsub;
	}
	public String getTcon() {
		return tcon;
	}
	public void setTcon(String tcon) {
		this.tcon = tcon;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	public String getTfinish() {
		return tfinish;
	}
	public void setTfinish(String tfinish) {
		this.tfinish = tfinish;
	}
	public String getTcnt() {
		return tcnt;
	}
	public void setTcnt(String tcnt) {
		this.tcnt = tcnt;
	}
	public String getCateno() {
		return cateno;
	}
	public void setCateno(String cateno) {
		this.cateno = cateno;
	}
	public String getTing() {
		return ting;
	}
	public void setTing(String ting) {
		this.ting = ting;
	}
	public String getTsingocnt() {
		return tsingocnt;
	}
	public void setTsingocnt(String tsingocnt) {
		this.tsingocnt = tsingocnt;
	}
	
}
