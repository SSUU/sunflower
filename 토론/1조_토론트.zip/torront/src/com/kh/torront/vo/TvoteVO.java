package com.kh.torront.vo;

public class TvoteVO {
	private String tvno;	 	
	private String tno;	
	private String tvote;	
	private String tvid;
	
	
	public String getTvno() {
		return tvno;
	}
	public void setTvno(String tvno) {
		this.tvno = tvno;
	}
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getTvote() {
		return tvote;
	}
	public void setTvote(String tvote) {
		this.tvote = tvote;
	}
	public String getTvid() {
		return tvid;
	}
	public void setTvid(String tvid) {
		this.tvid = tvid;
	}	
	
	
}
