package com.kh.torront.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class UDate {
	
	private Date today;
	private Date preday;
	private SimpleDateFormat tsdf;
	
	public UDate(){
		init();
	}
	
	private void init(){
		today = new Date();
		tsdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = new GregorianCalendar();
		c.add(Calendar.DATE, -1);
		
		try {
			today = tsdf.parse(tsdf.format(today));
			preday = c.getTime();
			preday = tsdf.parse(tsdf.format(preday));
		} catch (ParseException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		
	}
	
	public int compareToday(String data){
		
		Date readDay = null;
		try {
			readDay = tsdf.parse(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return readDay.compareTo(today);
	}
	
	public int comparePreday(String data){
		
		Date readDay = null;
		try {
			readDay = tsdf.parse(data);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return readDay.compareTo(preday);
		
	}
	
	public int compareTo(String d1, String d2){
		
		Date d1Day = null;
		Date d2Day = null;
		
		try {
			d1Day = tsdf.parse(d1);
			d2Day = tsdf.parse(d2);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("d1 : "+d1.toString());
		System.out.println("d2 : "+d2.toString());
		return d1.compareTo(d2);
	}

}
