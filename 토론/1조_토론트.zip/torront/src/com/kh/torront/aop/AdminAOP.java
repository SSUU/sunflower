package com.kh.torront.aop;

import org.aspectj.lang.JoinPoint;

public class AdminAOP {
	
	public void beforeMethod(){
		System.out.println("AOP !!! 호출");
	}
}
