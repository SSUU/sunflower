package com.kh.torront.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kh.torront.vo.AnalyAccessVO;
import com.kh.torront.vo.AnalyDateLogVO;
import com.kh.torront.vo.PageVO;

@Controller
public class AdminCont {
	@Autowired
	SqlMapClientTemplate sqlMapClientTemplate;

	@RequestMapping("adminlogin.lip")
	public String adminlogin(HttpServletRequest request) {

		String url = request.getRequestURL().toString();
		System.out.println("admin...." + url);
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println("id : " + id + ", pw : " + pw);

		return "/admin/dashboard.jsp";
	}

	@RequestMapping("admin.lip")
	public String admin(HttpServletRequest request) {
		String url = request.getParameter("t");
		System.out.println("admin , " + url);

		PageVO pVO = new PageVO();
		pVO.setPpath(url);
		// DAO
//		sqlMapClientTemplate.insert("cp.insertAnalyDateLog", pVO);

		return "/admin/admin.jsp";
	}

	@RequestMapping("analy_access.lip")
	public void analyAccess(AnalyAccessVO analyAccVO, HttpServletRequest request,
			HttpServletResponse response) {
		System.out.println("analy");
		System.out.println("browser : " + analyAccVO.getBrowser());
		
	}
	
//	@RequestMapping("adminpage.lip")
//	public String adminPage(){
//		System.out.println("param...l");
//		return "";
//	}

}
