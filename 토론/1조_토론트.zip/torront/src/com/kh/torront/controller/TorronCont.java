package com.kh.torront.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.kh.torront.vo.DatgleVO;
import com.kh.torront.vo.ListVO;
import com.kh.torront.vo.MemVO;
import com.kh.torront.vo.TvoteVO;

@Controller
public class TorronCont {
	
	double page = 0;
	@Autowired
	SqlMapClientTemplate sqlMapClientTemplate;
	
	@RequestMapping("view/torron/tcreate.lip")
	public void create(HttpServletRequest request, HttpServletResponse response, ListVO LVO ,MemVO mvo){
		//경준이 session
		mvo.setMemail("asd@asd.asd");
		HttpSession session = request.getSession();
		session.setAttribute("mvo", mvo);
		mvo = (MemVO)session.getAttribute("mvo");
		//
		System.out.println("제목: "+LVO.getTsub());
		System.out.println("내용 : "+LVO.getTcon());
		//url
		String url = LVO.getScrap().trim();
		//x자르기
		String[] urlValues = url.split("X");
//		for(int i = 0 ; i < urlValues.length ; i++){
//			System.out.println("url"+i+":" + urlValues[i].trim());
//		}
		String cate = LVO.getCateno();
		if(cate.equals("pol")){
			cate = "1";
		}else if(cate.equals("spo")){
			cate = "2";
		}else if(cate.equals("love")){
			cate = "3";
		}
		//DateFormat df = new DateFormat();
		System.out.println("카테고리넘버 :"+cate);
		String a = LVO.getCateno();
		System.out.println("마감날짜 : "+LVO.getTfinish());
		String t = LVO.getTfinish();
		LVO.setTtimer(t);
		String [] list = t.split("\\s+");

		String t1 = list[0];
		String t2 = list[2].substring(2,4);
		String t3 = list[1];
		//마감시간
		 switch (t1) {
		    case "jan" : t1 = "1"; break;
		    case "feb" : t1 = "2"; break;
		    case "mar" : t1 = "3"; break;
		    case "apr" : t1 = "4"; break;
		    case "may" : t1 = "5"; break;
		    case "jun" : t1 = "6"; break;
		    case "jul" : t1 = "7"; break;
		    case "aug" : t1 = "8"; break;
		    case "sep" : t1 = "9"; break;
		    case "oct" : t1 = "10"; break;
		    case "nov" : t1 = "11"; break;
		    case "dec" : t1 = "12"; break;
		  }
	
		 String s = "/";
		 String tf = t2 +s+ t1 +s+ t3;
		LVO.setTfinish(tf);
		LVO.setCateno(cate);
		sqlMapClientTemplate.insert("torron.insert",LVO);
		List<ListVO> llvo = sqlMapClientTemplate.queryForList("torron.mnores",mvo);
		
		LVO.setTno(llvo.get(0).getTno());
		for(int i = 0 ; i < urlValues.length ; i++){
			LVO.setSurl(urlValues[i].trim());
			System.out.println(LVO.getSurl());
			List<ListVO> svo = sqlMapClientTemplate.queryForList("torron.scrapsearch",LVO);
			
			//scrap 결과가 있는지 확인하는것.
			if(svo == null || svo.size() == 0){
				sqlMapClientTemplate.insert("torron.scrapinsert",LVO);
			}else{
				System.out.println("결과가 있습니다.");
			}
			String sno = (String)sqlMapClientTemplate.queryForObject("torron.ssrapno",LVO);
			LVO.setSno(sno);
			sqlMapClientTemplate.insert("torron.tscrap",LVO);
		}

		//날짜 ??/??/??
		PrintWriter out;
		try {
			out = response.getWriter();
			out.print("1");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		 
//		 List<ListVO> list = sqlMapClientTemplate.queryForList("torron.select");
//		 
	}
	
	@RequestMapping("endtorron.lip")
	public void endtorron(HttpServletRequest request ,HttpServletResponse response,ListVO lvo){
		PrintWriter out;
		int result = 0;
		String ttimer = "";
		String tno = request.getParameter("tno");
		lvo.setTno(tno);
		String ting = (String)sqlMapClientTemplate.queryForObject("torron.endselect",lvo);
		System.out.println("result :"+ting);
	
	
		if(ting.equals("진행중")){
			System.out.println("aaa");
			ting = "마감";
			ttimer = "oct 15 2014 18:05:05";
			lvo.setTing(ting);
			lvo.setTtimer(ttimer);
			result = sqlMapClientTemplate.update("torron.endtorron",lvo);
			try {
				out = response.getWriter();
				out.print(result);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			System.out.println("이미 마감");
			try {
				out = response.getWriter();
				out.print(result);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	// - 정호 메인하고 내용 20151015
	@RequestMapping("mainsub.lip")
	public void mainsub(HttpServletRequest request, HttpServletResponse response, ListVO lvo){
		String main =request.getParameter("main");
		String sub = request.getParameter("sub");
		String bono = request.getParameter("tno");
		lvo.setTsub(main);
		lvo.setTcon(sub);
		lvo.setTno(bono);
		int res = sqlMapClientTemplate.update("torron.mainsub",lvo);
	}
	//정호	
////////////////////정호
	@RequestMapping("paging.lip")
	public void paging(HttpServletRequest request,HttpServletResponse response,ListVO lvo){
	String a = (String)sqlMapClientTemplate.queryForObject("torron.pagecnt");
	double b = Integer.parseInt(a);			
	page = b;
		double pageno = Math.ceil(page/10);
			if(pageno == 0 ){
				pageno = 1;
				}
				PrintWriter out;
				try {
					out = response.getWriter();
					out.print(pageno);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
}/////page
	//////
	@RequestMapping("select.lip")
	public void sresult(HttpServletResponse response,ListVO lvo, HttpServletRequest request){
		//경준이 session
				HttpSession session = request.getSession();
				lvo.setMemail("asd@asd.asd");
				session.setAttribute("lvo", lvo);
		//
		PrintWriter out;
		try {
			 List<ListVO> list = sqlMapClientTemplate.queryForList("torron.select");
			 ArrayList<HashMap<String, String>> al = new ArrayList<HashMap<String,String>>();
			 HashMap<String, String> map = null;
			 ////////////
			 String no = request.getParameter("pno");
				int number = 1;
				if(no == null){
					
				}else{
					number = Integer.parseInt(no);
				}
				int exmax = 9;
				int exmin = 0;
				
				exmax = (number * 10)-1 ;
				exmin = (exmax - 9);
				
				int pa = (int)page;
				
				if(pa < exmax && exmax%pa != 0 ){
					int eee = exmax - pa;
					exmax = exmax - eee-1;
				}
				System.out.println(number);
				System.out.println(pa);
				System.out.println(exmin);
				System.out.println(exmax);
				
			 ///////////
			 for(int i=exmin; i <= exmax; i++){
				 map = new HashMap<String, String>();
				 map.put("tno", list.get(i).getTno());
				 map.put("ting",list.get(i).getTing());
				 map.put("memail", list.get(i).getMemail());
				 map.put("tsub", list.get(i).getTsub());
				 map.put("tdate", list.get(i).getTdate());
				 map.put("mnic", list.get(i).getMnic());
				 
				 al.add(map);
			 }
			 response.setCharacterEncoding("UTF-8");
			 request.setCharacterEncoding("UTF-8");
			 
			ObjectMapper mapper = new ObjectMapper();
			out = response.getWriter();
			out.print(mapper.writeValueAsString(al));
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	@RequestMapping("room.lip")
	public String room_a(HttpServletRequest request, HttpServletResponse response){
		System.out.println("1");
		return "torron/room.jsp";
	}
	
	String boardno ="";
	@RequestMapping("rcontents.lip")
	public void roomcontents(HttpServletRequest request, ListVO lvo, HttpServletResponse response,DatgleVO dvo,TvoteVO tvo){
		System.out.println("rcon");
		HashMap<String, Object> map = null;
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			//경준
			HttpSession session = request.getSession();
			lvo = (ListVO)session.getAttribute("lvo");
//			boardno = request.getParameter("nono");
//			lvo.setTno(boardno);
//			List<TvoteVO> tlist = sqlMapClientTemplate.queryForList("torron.gender",lvo);
			//--
			boardno = request.getParameter("nono");
			session.setAttribute("boardno", boardno);
			lvo.setTno(boardno);
			List<TvoteVO>  tlist = sqlMapClientTemplate.queryForList("torron.gender",lvo);
			
			dvo.setTno(boardno);
			List<ListVO> list = sqlMapClientTemplate.queryForList("torron.boardno",lvo);
			List<DatgleVO> datlist = sqlMapClientTemplate.queryForList("torron.datcon",dvo);
			tvo.setTno(boardno);
			List<TvoteVO> votetotal = sqlMapClientTemplate.queryForList("torron.votecnt",tvo);
			List<TvoteVO> voteban = sqlMapClientTemplate.queryForList("torron.votetype",tvo);
			
			map = new HashMap<String, Object>();
			ArrayList<HashMap<String, String>> al=null;
			al  = new ArrayList<HashMap<String,String>>();
			if(list != null){
				map.put("list", list);
			}
			if(voteban != null){
				map.put("voteban", voteban);
			}
			if(votetotal != null){
				map.put("votetotal", votetotal);
			}
			if(datlist != null){
				map.put("datlist", datlist);
			}
			if(tlist != null){
				map.put("tlist", tlist);
			}
			
		} catch (UnsupportedEncodingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		ObjectMapper obj = new ObjectMapper();
		try {
			PrintWriter out = response.getWriter();
			out.print(obj.writeValueAsString(map));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}//roomcontents
	
	//댓글 insert 부분
	@RequestMapping("datglelist.lip")
	public void datglelist(HttpServletRequest request,ListVO lvo,HttpServletResponse response){
			try {
				System.out.println("datglelist");
				request.setCharacterEncoding("UTF-8");
				response.setCharacterEncoding("UTF-8");
				String no =request.getParameter("hidno");
				String txt = URLDecoder.decode(request.getParameter("hidtxt"), "UTF-8");
				lvo.setTno(boardno);
				lvo.setTcon(txt);
				sqlMapClientTemplate.insert("torron.datglelist",lvo);
				
			} catch (UnsupportedEncodingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
	}//datglelist
	@RequestMapping("datupdate.lip")
	public void datupdate(HttpServletRequest request,HttpServletResponse response,DatgleVO dvo){
		
		PrintWriter out;
		try {
			
			String tdatno = request.getParameter("delcontents");
			System.out.println(tdatno);
			dvo.setTdatno(tdatno);
			int res = sqlMapClientTemplate.delete("torron.datdelete",dvo);
			System.out.println(res);
			out = response.getWriter();
			out.print(res);
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}//datupdate
	@RequestMapping("tingupdate.lip")
	public void tingupdate(HttpServletRequest request,HttpServletResponse response,ListVO lvo){
		String boardno = request.getParameter("boardno");
		lvo.setTno(boardno);
		String a = (String)sqlMapClientTemplate.queryForObject("torron.sboard",lvo);
		if(a.equals("진행중")){
			int tingres = sqlMapClientTemplate.update("torron.updateting",lvo);
			System.out.println(tingres);
			if(tingres == 1){
				System.out.println("ting 가 마감으로 수정되었습니다.");
			}//if
		}
	}//tingupdate
	@RequestMapping("datsingo.lip")
	public void singo(HttpServletResponse response,HttpServletRequest request,DatgleVO dvo){
		System.out.println("댓글신고");
		String con = request.getParameter("con");
		String datno = request.getParameter("datno");
		String mnic = request.getParameter("mnic");
		System.out.println(mnic);
		System.out.println(datno);
		dvo.setMnic(mnic);
		dvo.setTdatno(datno);
		dvo.setTdatcon(con);
		sqlMapClientTemplate.insert("torron.datsingo",dvo);
	}//singo
	
	@RequestMapping("torronreport.lip")
	public void torronreport(HttpServletRequest request,HttpServletResponse response,ListVO lvo){
		String treportno = request.getParameter("tno");
		System.out.println(treportno);
		lvo.setTno(treportno);
		sqlMapClientTemplate.insert("torron.torronreport",lvo);
		
		
	}//torronreport
	@RequestMapping("cnttvote.lip")
	public void cnttvote(HttpServletRequest request,HttpServletResponse response,TvoteVO tvo){
		HashMap<String, Object> map = null;
		try {
			System.out.println(boardno);
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			tvo.setTno(boardno);
			List<TvoteVO> tvotecnt =sqlMapClientTemplate.queryForList("torron.votecnt",tvo);
			List<TvoteVO> voteban = sqlMapClientTemplate.queryForList("torron.votetype",tvo);
			
			map = new HashMap<String, Object>();
			if(tvotecnt != null ){
				map.put("tvotecnt", tvotecnt);	
			}
			if(tvotecnt != null ){
				map.put("voteban", voteban);	
			}
			
			ObjectMapper obj = new ObjectMapper();
			PrintWriter	out = response.getWriter();
			out.print(obj.writeValueAsString(map));
			
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}catch (IOException e) {
			e.printStackTrace();
		}
		
	}//cnttvote
	
	@RequestMapping("chanbanvote.lip")
	public void chanbanvote(HttpServletRequest request,HttpServletResponse response,ListVO lvo){
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
			HttpSession session = request.getSession();
			lvo = (ListVO)session.getAttribute("lvo");
			String gen = (String)sqlMapClientTemplate.queryForObject("torron.memgen",lvo);
			String board = (String)session.getAttribute("boardno");
			lvo.setTno(board);
			System.out.println(gen);
			String vvote = URLDecoder.decode(request.getParameter("vvote"),"UTF-8");
			 System.out.println(vvote);
			if(vvote.equals("찬성")){
				if(gen.equals("b")){
					System.out.println("남자");
					lvo.setTvote("0");
					sqlMapClientTemplate.insert("torron.cbvote",lvo);
				}else if(gen.equals("g")){
					System.out.println("여자");
					lvo.setTvote("2");
					sqlMapClientTemplate.insert("torron.cbvote",lvo);
				}
			}
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}//chanbanvote
}