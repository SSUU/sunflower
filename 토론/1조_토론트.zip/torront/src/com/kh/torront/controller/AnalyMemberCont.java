package com.kh.torront.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kh.torront.util.UDate;
import com.kh.torront.vo.AnalyMDetailVO;
import com.kh.torront.vo.AnalyTorronVO;
import com.kh.torront.vo.ListVO;
import com.kh.torront.vo.MemberInfoVO;
import com.kh.torront.vo.MemberSignupCnt;
import com.kh.torront.vo.RoomDatHistoryVO;
import com.kh.torront.vo.RoomDetailVO;
import com.kh.torront.vo.RoomscrapVO;
import com.kh.torront.vo.SearchDateVO;

@Controller
public class AnalyMemberCont {
	@Autowired
	SqlMapClientTemplate sqlMapClientTemplate;

	@RequestMapping("printAnalyMember.lip")
	public String printAnalyMember(HttpServletRequest request,
			HttpServletResponse response, UDate udate) {

		List<MemberInfoVO> mvoList = sqlMapClientTemplate
				.queryForList("analymember.sel-memberAll");

		MemberSignupCnt mCnt = new MemberSignupCnt();
		for (int i = 0; i < mvoList.size(); i++) {
			MemberInfoVO vo = mvoList.get(i);
			String date = vo.getIndate();
			int reTo = udate.compareToday(date);
			System.out.println("r : " + reTo);
			if (reTo == 0) {
				// 같음
				mCnt.setToCnt(mCnt.getToCnt() + 1);
			} else if (reTo < 0) {
				// 느림
				int rePre = udate.comparePreday(date);
				if (rePre == 0) {
					// 전날
					mCnt.setPreCnt(mCnt.getPreCnt() + 1);
				}
			} else {
				// 빠름
			}

			if (vo.getState().equals("탈퇴")) {
				mCnt.setOutCnt(mCnt.getOutCnt() + 1);
			}
			mCnt.setAllCnt(mCnt.getAllCnt() + 1);
		}

		System.out.println("t : " + mCnt.getToCnt() + ", p : "
				+ mCnt.getPreCnt() + ", a : " + mCnt.getAllCnt() + ", o : "
				+ mCnt.getOutCnt());

		Map map = new HashMap();
		map.put("membersignupcnt", mCnt);
		map.put("list", mvoList);

		HttpSession session = request.getSession();
		session.setAttribute("list", map);

		ObjectMapper om = new ObjectMapper();
		try {
			om.writeValue(response.getWriter(), mvoList);
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return "";
	}

	@RequestMapping("printSearchDateAnalyMember.lip")
	public void printSearchDateAnalyMember(HttpServletRequest request,
			HttpServletResponse response, SearchDateVO searchDateVO, UDate uDate) {

		HttpSession session = request.getSession();
		Map map = (Map) session.getAttribute("list");
		List<MemberInfoVO> mvoList = (List<MemberInfoVO>) map.get("list");

		for (int i = 0; i < mvoList.size(); i++) {
			String date = mvoList.get(i).getIndate();
			int r1 = uDate.compareTo(date, searchDateVO.getStartDate());
			int r2 = uDate.compareTo(date, searchDateVO.getEndDate());
			System.out.println("r1 : " + r1 + ", r2 : " + r2);
			if (r1 < 0 || r2 > 0) {
				System.out.println("= 삭제");
				mvoList.remove(i);
			}
		}

		map.put("list", mvoList);

		session.setAttribute("list", map);

	}

	@RequestMapping("printAnalyMemberInfo.lip")
	public void printAnalyMemberInfo(HttpServletRequest request,
			HttpServletResponse response, AnalyMDetailVO analyMDetailVo) {
		try {
			request.setCharacterEncoding("UTF-8");
			response.setCharacterEncoding("UTF-8");
		} catch (UnsupportedEncodingException e2) {
			// TODO Auto-generated catch block
			e2.printStackTrace();
		}
		System.out.println("ddddd");
		
		// 멤버 정보
		List<AnalyMDetailVO> mInfo = sqlMapClientTemplate
				.queryForList("analymember.sel-memberDetail", analyMDetailVo);
//		// 토론방
		List<AnalyTorronVO> tInfoList =  sqlMapClientTemplate
				.queryForList("analymember.sel-torronList", analyMDetailVo);
//		// 신고
//		List<AnalyReportVO> rInfoList = sqlMapClientTemplate
//				.queryForList("analymember.sel-reportList", analyMDetailVo);
		Map map = new HashMap();
		map.put("mInfo", mInfo.get(0));
		map.put("tInfoList", tInfoList);
		
		for(int i=0; i<tInfoList.size(); i++){
			System.out.println("sss : "+tInfoList.get(i).getCate());
		}
//		map.put("rInfoList", rInfoList);
		
		ObjectMapper om = new ObjectMapper();
		try {
			om.writeValue(response.getWriter(), map);
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@RequestMapping("analy_rcontents.lip")
	public void analyRcontents(HttpServletRequest request, HttpServletResponse response){
		
		String tno = request.getParameter("nono");
		System.out.println("tno1111 : "+tno);
		ListVO lvo = new ListVO();
		lvo.setTno(tno);
		
		RoomDetailVO rDetail = (RoomDetailVO) sqlMapClientTemplate.queryForObject("analymember.sel-roomdetail", lvo);
		List<RoomscrapVO> rScrapList = sqlMapClientTemplate.queryForList("analymember.sel-roomscrap", lvo); 
		List<RoomDatHistoryVO> rdHistoryList = sqlMapClientTemplate.queryForList("analymember.sel-roomdathistory", lvo); 
		
		Map map = new HashMap();
		map.put("rDetail", rDetail);
		map.put("rdHistoryList", rdHistoryList);
		map.put("rScrapList", rScrapList);
		
		HttpSession session = request.getSession();
		session.setAttribute("list", map);
	}
}
