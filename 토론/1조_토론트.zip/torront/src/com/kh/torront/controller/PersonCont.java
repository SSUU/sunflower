package com.kh.torront.controller;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.kh.torront.vo.ContentlistVO;
import com.kh.torront.vo.LoginLogVO;
import com.kh.torront.vo.MemVO;
import com.kh.torront.vo.ReportDatgle;
import com.kh.torront.vo.ReportRoom;

@Controller
public class PersonCont {
	@Autowired
	SqlMapClientTemplate sqlMapClientTemplate;
	MemVO memVO;

	// 회원 가입 시 - 아이디 중복 확인
	@RequestMapping("idchk.lip")
	public void idchk(MemVO vo, HttpServletResponse response) {
		String memail = (String) sqlMapClientTemplate.queryForObject(
				"member.idchk", vo);
		System.out.println(memail);

		boolean bMemail = false;
		if (memail != null) {
			bMemail = true;
		}
		PrintWriter out = null;
		try {
			out = response.getWriter();
			out.print(bMemail);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	// 회원 가입 시 - 닉네임 중복 확인
	@RequestMapping("nickchk.lip")
	public void nickchk(MemVO vo, HttpServletResponse response) {
		String mnic = (String) sqlMapClientTemplate.queryForObject(
				"member.nickchk", vo);
		System.out.println(mnic);
		boolean bmnic = false;
		if (mnic != null) {
			bmnic = true;
		}
		PrintWriter out = null;
		try {
			out = response.getWriter();
			out.print(bmnic);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}
	
	// 비밀번호 찾기 시 - 아이디와 이름으로 확인
	@RequestMapping("findpw.lip")
	public void findpw(MemVO vo, HttpServletResponse response){
	
		String pw = (String) sqlMapClientTemplate.queryForObject("member.findpw",vo);

		PrintWriter out = null;
		try {
			out = response.getWriter();
			out.print(pw);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			out.close();
		}
	}
	
	// 회원가입
	@RequestMapping("signup.lip")
	public void signup(MemVO vo, HttpServletResponse response) {
		System.out.println("signup...");
		sqlMapClientTemplate.insert("member.signup", vo);
		
		Map result = new HashMap();
		result.put("result", true);
		
		ObjectMapper om = new ObjectMapper();
		try {
			om.writeValueAsString(result);
			om.writeValue(response.getWriter(), result);
			System.out.println(result);
			System.out.println(om);
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// 로그인
	@RequestMapping("login.lip")
	public void login(MemVO vo, LoginLogVO loginLogVO, HttpServletResponse response,
			HttpServletRequest request) {
		MemVO memberVO = (MemVO) sqlMapClientTemplate.queryForObject(
				"member.login", vo);
		loginLogVO.setMno(memberVO.getMno());
		sqlMapClientTemplate.insert("member.loginlogInsert", loginLogVO);
		System.out.println(memberVO);

		HttpSession session = request.getSession();
		boolean blogin = false;
		if (memberVO != null) {
			
			loginLogVO.setMno(memberVO.getMno());
			// 로그인 로그 기록
//			sqlMapClientTemplate.insert("member.loginLogInsert", loginLogVO);
			
			blogin = true;
			System.out.println(blogin);
			session = request.getSession();
			session.setAttribute("login", true);
			session.setAttribute("memberVO", memberVO);
			
		}
		PrintWriter out = null;
		try {
			out = response.getWriter();
			out.print(blogin);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
	}

	// 로그아웃
	@RequestMapping("logout.lip")
	public void logout(HttpServletResponse response, HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.setAttribute("login", false);
		session.setAttribute("list", null);
		MemVO vo = (MemVO) session.getAttribute("memberVO");
		
		sqlMapClientTemplate.update("member.loginoutUpdate", vo);

	}
	
	// 회원탈퇴
	@RequestMapping("userout.lip")
	public void userout(MemVO vo, HttpServletResponse response,
			HttpServletRequest request) {
		System.out.println();
		
		HttpSession session = request.getSession();
		vo.setMemail(((MemVO) session.getAttribute("memberVO")).getMemail());

		int outid = sqlMapClientTemplate.delete("member.userout", vo);
		System.out.println(outid);

		PrintWriter out = null;
		try {
			out = response.getWriter();
			out.print(outid);
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			out.close();
		}
		session.setAttribute("login", false);
	}
	
	// 회원 정보 수정
	@RequestMapping("update.lip")
	public void update(MemVO vo, HttpServletResponse response,
			HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		try {
			System.out.println(vo.getMemail());
			
			MemVO memberVO = (MemVO) session.getAttribute("memberVO");
			vo.setMno(memberVO.getMno());
			int updateScnt = 0;
			
			if(vo.getMpw() == null || vo.getMpw().equals("")){
				updateScnt = sqlMapClientTemplate.update("member.updateNic", vo);
			}else{
				updateScnt = sqlMapClientTemplate.update("member.update", vo);
			}
			System.out.println(updateScnt);
			
			if(updateScnt == 1){
				memberVO.setMnic(vo.getMnic());
				session.setAttribute("memberVO", memberVO);
			}
			
			Map result = new HashMap();
			result.put("mnic", vo.getMnic());
			ObjectMapper om = new ObjectMapper();
			om.writeValue(response.getWriter(), result);
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// 회원이 가진 권한 확인 - 비밀번호로 확인 후 권한 부여
	@RequestMapping("confirmuser.lip")
	public void confirmuser(HttpServletRequest request,
			HttpServletResponse response, MemVO vo) {
		
		boolean b = false;
		HttpSession session = request.getSession();
		vo.setMemail(((MemVO) session.getAttribute("memberVO")).getMemail());

		MemVO memVO = (MemVO) sqlMapClientTemplate.queryForObject(
				"member.confirmuser", vo);

		if (memVO != null) {
			b = true;
		}


		Map result = new HashMap();
		result.put("result", b);
		
		ObjectMapper om = new ObjectMapper();
		try {
			om.writeValueAsString(result);
			om.writeValue(response.getWriter(), result);
			System.out.println(result);
			System.out.println(om);
		} catch (JsonProcessingException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
//		System.out.println("email : "+vo.getMemail()+" , pw + "+vo.getMpw()+" , vo : "+memVO);

	}

	//
	@RequestMapping("contentlist.lip")
	public void contentlist(HttpServletResponse response, HttpServletRequest request){
		
		HttpSession session = request.getSession();
		MemVO vo = (MemVO)session.getAttribute("memberVO");
		List<ContentlistVO> list = sqlMapClientTemplate.queryForList("member.contentlist", vo);
		System.out.println("contentlist : "+vo.getMno() );
		session.setAttribute("mytorron", list);
		ObjectMapper om = new ObjectMapper();
		try {
			om.writeValue(response.getWriter(), list);
		} catch (JsonProcessingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@RequestMapping("blacklist.lip")
	public void report(HttpServletRequest request, HttpServletResponse response){
		
		HttpSession session = request.getSession();
		MemVO vo = (MemVO)session.getAttribute("memberVO");

		ArrayList list = new ArrayList();
		
		List<ReportRoom> rlist = sqlMapClientTemplate.queryForList("report.room", vo);
		List<ReportDatgle> dlist = sqlMapClientTemplate.queryForList("report.datgle", vo);
		List<MemVO> blist = sqlMapClientTemplate.queryForList("report.blacklist", vo);
		
		list.add(rlist);
		list.add(dlist);
		list.add(blist);

		session.setAttribute("list", list);
		System.out.println("aaaa : "+vo.getMno());
	}
}
