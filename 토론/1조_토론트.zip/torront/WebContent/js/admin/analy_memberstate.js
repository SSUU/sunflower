var tInfoList = null;

$(document).ready(function(){
	analy_memberstateEvent();
//	google.laod('visualization','1.0',{'packages':['corechart']});
//	google.setOnLoadCallback(drawChart);

});

function drawChart() {
	
    var data = google.visualization.arrayToDataTable([
      ['Year', 'Sales', 'Expenses'],
      ['2004',  1000,      400],
      ['2005',  1170,      460],
      ['2006',  660,       1120],
      ['2007',  1030,      540]
    ]);

    var options = {
      title: 'Company Performance',
      curveType: 'function',
      legend: { position: 'bottom' }
    };

    var chart = new google.visualization.LineChart($("#curve_chart1"));

    chart.draw(data, options);
  }

function analy_memberstateEvent(){
	
	$(".contents").on("click",".aaa", function(e){
		var data = {
				page : tPath.getView("analymember"),
				r : $(this).text()
		};
		$.get("view/"+tPath.getView("analymember"),data,function(result){
			$(".contents > div").replaceWith(result);
		});
	});
	
	$("#analymember-searchBtn").click(function(){
		
		var data = {
				startDate : $("#msdate").val(),
				endDate : $("#medate").val()
		};
		
		$.post("./printSearchDateAnalyMember.lip", data, function(){
			$.get("view/"+tPath.getView("analymember"),data,function(result){
				$(".contents > div").replaceWith(result);
			});
		});
		
	});
	
	$("#membersignup-table tr").click(function(){
//		var target = $(this).children("td:nth-child(6)").text();
		var target = {
				indate : $(this).children("td:nth-child(2)").text(),
				inlogin : 'eee',
				state : $(this).children("td:nth-child(4)").text(),
				email : $(this).children("td:nth-child(5)").text(),
				nic : $(this).children("td:nth-child(6)").text(),
				gender : $(this).children("td:nth-child(7)").text(),
				reportCnt : $(this).children("td:nth-child(8)").text(),
		};
		
		var data = {
				email : $(this).children("td:nth-child(5)").text()
		};
		$.post("./printAnalyMemberInfo.lip", data, function(result){
			var data = JSON.parse(result);
			var mInfo = data.mInfo;
			tInfoList = data.tInfoList;

			$(".detail1 .indate").text(target.indate);
			$(".detail1 .inlogin").text(target.inlogin);
			$(".detail1 .state").text(target.state);
			$(".detail1 .email").text(target.email);
			$(".detail1 .nic").text(target.nic);
			$(".detail1 .gender").text(target.gender);
			$(".detail1 .reportCnt").text(target.reportCnt);
			$(".detail1 .omsg").text(mInfo.omsg);
			
//			<th>번호</th>
//			<th>카테고리</th>
//			<th>토론명</th>
//			<th>개설일</th>
//			<th>종료일</th>
//			<th>상태</th>
//			<th>참여수</th>
//			<th>찬:반</th>
//			<th>신고</th>
//			<th>관리</th>
			
			addTableDetail3Cnt();
			addTableDetail3(1);
			var rPage = "";
			var rPageCnt = 0;
			for(var i=0; i<tInfoList.length; i+=10){
				rPageCnt++;
				rPage += "<span>"+rPageCnt+"</span>";
			}
			
			$(".detail3 .pages > .pnumbers").empty();
			$(".detail3 .pages > .pnumbers").append(rPage);
			$(".detail3 .pages > .pnumbers > span").click(function(){
				var sIdx = $(this).text();
				addTableDetail3(sIdx);
			});
			
//			<p class="pages">
//			<span class="pagenum">&lt</span><a href="">1</a><a href="">2</a><span
//				class="pagenum">&gt</span>
//		</p>
		});
	});
}
function addTableDetail3Cnt(){
	
	var rAllCnt = tInfoList.length;
	var rOpenCnt = 0;
	var rClosedCnt = 0;
	var rReportCnt = 0;
	
	for(var i=0; i<rAllCnt; i++){
		var n = tInfoList[i];
		if(n.ing === '진행중'){
			rOpenCnt++;
		}else if(n.ing === '마감'){
			rClosedCnt++;
		}
		
	}
	
	$(".detail3 .allcnt").text(rAllCnt);
	$(".detail3 .opencnt").text(rOpenCnt);
	$(".detail3 .closedcnt").text(rClosedCnt);
	$(".detail3 .reportcnt").text(rReportCnt);
	
}
function addTableDetail3(sIdx){
	
	var add = "";
	
	sIdx = (sIdx - 1) * 10;
	
	for(var i=0; i<10; i++){
		if(sIdx+i >= tInfoList.length){
			break;
		}
		add += "<tr>";
		var n = tInfoList[sIdx+i];
		add += "<td>"+n.no+"</td>"
		+"<td>"+n.cate+"</td>"
		+"<td>"+n.sub+"</td>"
		+"<td>"+n.tdate+"</td>"
		+"<td>"+n.odate+"</td>"
		+"<td>"+n.ing+"</td>"
		+"<td><span>방관리</span></td></tr>";
	}
	
	$(".detail3 table > tbody").empty();
	$(".detail3 tbody").append(add);
	
	$(".detail3 td > span").click(function(){
		var tno = $(this).parent().parent().children("td:nth-child(1)").text().trim();
		$.ajax({
			url : "./analy_rcontents.lip",
			type : "get",
			cache : false,
			data : {
				nono : tno
			},
			success : function() {
//				$("#listmenu").text("");
//				var rjson = JSON.parse(result);
//				var roomcon = new Array();
//				
//				var list = rjson.list;
//				var datlist = rjson.datlist;
//				var tlist = rjson.tlist;
//				var votetotal = rjson.votetotal;
//				var voteban = rjson.voteban;
//				roomcon = rjson;
				//토론방내용 뿌려줄때.
				
				$(".contents > div").load("view/"+tPath.getView("roomdetail"), function() {
					
//					$(".head > label").text(list[0].tsub);
//					$(".t_contents > label").text(list[0].tcon);
//					$("#hidtimer").val(list[0].ttimer);
//					$(".t_host > label").text(list[0].mnic);
//					$("#boardnumber > label").text(boardno);
//					$(".tbtn").attr("disabled","disabled");
//					$(".ta").attr("disabled","disabled");
//					$(".ta").attr("placeholder","투표를 해야 댓글을 작성 할 수 있습니다..");
//					//댓글리스트 
//					var no=0;
//					for(var i=0;i<datlist.length;i++){
//						 var ss = "<fieldset class ='"+datlist[i].mnic+"' id='"+no+"'>작성자 : "+datlist[i].mnic+"<br/><label class ='"+no+"' id='"+datlist[i].tdatno+"'>"+datlist[i].tdatcon+"</label>&nbsp;&nbsp;<button class='ox' id='"+no+"'>X</button><br/><button class='singo' id='sin"+no+"'>신고하기</button></fieldset>";
//							$("#c3").append(ss);
//							no++;
//					}
//					//총투표수 표시
//					var votetotalcnt = votetotal[0].tvote - voteban[0].tvote;
//					
//					$("#ttotal").text("총 :"+votetotal[0].tvote+"명 중,찬성 : "+votetotalcnt+"명, 반대 : "+voteban[0].tvote+"명 입니다.");
//					
//					$(".gbtn").click(function(){
//						alert("눌럿네");
//						var vote = $(this).text();
//						if(vote == "찬성"){
//							$("#ttotal").text("총 :"+(parseInt(votetotal[0].tvote)+1)+"명 중,찬성 : "+(votetotalcnt+1)+"명, 반대 : "+voteban[0].tvote+"명 입니다.");
//						}else if(vote == "반대"){
//							$("#ttotal").text("총 :"+(parseInt(votetotal[0].tvote)+1)+"명 중,찬성 : "+(votetotalcnt)+"명, 반대 : "+(parseInt(voteban[0].tvote)+1)+"명 입니다.");
//						}
//					});
//					//투표에 관한 유효성
//					if(tlist[0].tvote != null || tlist[0].tvote != ""){
//						$(".cbtn").text("이미 투표했습니다.");
//						$(".cbtn").css("font-size","x-large");
//						$(".tbtn").removeAttr("disabled");
//						$(".ta").removeAttr("disabled");
//						$(".ta").attr("placeholder","댓글");
//						return;
//					}
//					
//					//정호수정
//					$("#rename").attr("class",boardno);
//					/////////////////////////////////
//					
//					//방신고 누를시,
//					$("#roomreport").click(function(){
//						alert(boardno);
//						$.ajax({
//							url:"../torronreport.lip",
//							type:"get",
//							cache:"false",
//							data:{tno:boardno},
//							success:function(){
//								
//							}
//						})//ajax
//					});//방신고 클릭시
//					
//					//댓글 신고하기누를시,
//					$(".singo").click(function(){
//						var sno = $(this).parent().attr("id");
//						scontents = $("fieldset > label[class='"+sno+"']").text();
//						tdatno = $("fieldset > label[class='"+sno+"']").attr("id");
//						mnic = $("fieldset[id='"+sno+"']").attr("class");
//						window.open("../view/torron/singo.jsp","singo","width=220, height=120");
//					});
//					
//					///삭제버튼 누를시,
//					$(".ox").click(function(){
//						var cno = $(this).attr("id");
//						alert(cno);
//						
//						//댓글삭제 유효성해야함.
//						var delcon = $("label[class='"+cno+"']").attr("id");
//						$.ajax({
//							url:"../datupdate.lip",
//							type:"get",
//							data:{delcontents:delcon},
//							cache:false,
//							success:function(result){
//								alert(result);
//								$("fieldset[id='"+cno+"']").remove();
//							}//function
//						})//ajax
//					
//					});
				});//room load
				
			}
		});
	});
	
}

