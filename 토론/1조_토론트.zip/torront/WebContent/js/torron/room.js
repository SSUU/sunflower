$(document).ready(function(){
	createRoomEvent();
	rename();
});

// 방 개설시 필요한 정보를 data 객체에 담아 사용
function returnT(data){
	
	$(".head > span").text(data.subject);
	$(".t_host > span").text(data.host);
	$(".t_contents > span").text(data.contents);
	
}
var loadFileName = "";
function createRoomEvent(){
	$("#list").click(function() {
		loadFileName = $(this).attr("id");
		//boardlist();
		$(".contents").load(tPath.getView(loadFileName));
	});

}

function rename(){
	$("#rename").click(function(){
		var boardnum = $("#rename").attr("class");
		$(".contents").load(tPath.getView("rename"),function(){
			$("#bnumber > label").text(boardnum);
		});
	})
}

//function toto(){
//	var obj = document.getElementById('ttotal');
//	var tt = "총 :"+(total-2)+"명 중, 찬성 :"+(chan-1)+"명/ 반대"+(ban-1)+"명";
//	obj.innerHTML = tt;
//}

// graph

function chattingGraphInit(){
	//찬성 버튼 호버
	$("#chan").hover(function(){
		$(this).css("background-color","white");
		$(this).css("color","black");
	},function(){
		$(this).css("background-color","blue");
		$(this).css("color","white");
	});
	//반대 버튼 호버
	$("#ban").hover(function(){
		$(this).css("background-color","white");
		$(this).css("color","black");
	},function(){
		$(this).css("background-color","red");
		$(this).css("color","white");
	});
	
	//찬 반 버튼 클릭시,
	
}

function boardlist(){
	if(loadFileName == "list"){
		$.ajax({
			url : "../select.lip",
			type:"get",
			success:function(result){
				$(".contents").load(tPath.getView(loadFileName),function(){
					var tata = JSON.parse(result);
					var a = new Array();
						 a  = tata;
					
					if(tata.length > 0){
						var tableTr = "<tr>";
						for(var i = 0;i<tata.length;i++){
							tableTr+="<td align='center'>"+a[i].tno+"</td>" +
									"<td align='center'><label id='"+a[i].tno+"'>"+a[i].tsub+"</label></td>" +
									"<td align='center'>"+a[i].mnic+"</td>" +
									"<td align='center'>"+a[i].tdate.substring(0,10)+"</td>" +
									"<td align='center'>"+a[i].ting+"</td></tr>" ;
						}
						$("#t_listTable").append(tableTr);
						boardclick();
					}//if
					
					
				});
				
			} //success!
			});//ajax 
	}
	
	
}
function boardclick(){
	//게시판 넘버 가져온다.
	$("td > label").click(function(){
		$(".contents").load(tPath.getView("room"));
	});
	//게시판 리스트 호버.
	$("td > label").hover(function(){
		$(this).css("color","red");
	},function(){
		$(this).css("color","black");
	});
	
	
}
