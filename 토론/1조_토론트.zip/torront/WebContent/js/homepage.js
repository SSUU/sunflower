$(document).ready(function() {
	getAccessInfo();
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// session 을 통한 로그인 유효성 검사
	// li 태그 로그인 text를 마이페이지로 변경
	//var url = location.pathname;
	var uri = document.documentURI;
	if(uri.match(/adminlogin.lip/g)){
		$(".contents > div").load("view/"+tPath.getView($(".main-sidemenu > li:nth-child(2)").attr("id")));
		adminMenuControll();
	}else{
		menuControll();
		headerControll();
	}	
});

var tPath = pathContainer();
var info = {
		loc : "",
		browser : "",
		path : ""
}

function getAccessInfo(){
	var onSuccess = function(location) {
		info.loc = location.city.names.en;
	};

	var onError = function(error) {
		alert("Error:\n\n" + JSON.stringify(error, undefined, 4));
	};
	geoip2.city(onSuccess, onError);
	
	var userAgent = navigator.userAgent.toLowerCase();
	var o = "";
	var start = 0;
	var end = 0;
	var ver = "";

	if ((navigator.appName == "Netscape" && navigator.userAgent
			.search("Trident") != -1)
			|| (userAgent.indexOf("msie") != -1)) {
		start = userAgent.search("msie") + 4;
		end = userAgent.search("windows") - 2;
		ver = userAgent.slice(start, end).trim();

		if (userAgent.indexOf("msie") != -1) {
			o = "MS/" + ver;
		} else {
			// ms 11 
			o = "MS/" + ver;
		}
	} else {
		if (userAgent.indexOf("chrome") != -1) {
			start = userAgent.search("chrome");
			end = userAgent.search("safari") - 1;
			ver = userAgent.slice(start, end).trim();
			o = ver;
		} else if (userAgent.indexOf("safari") != -1) {
			start = userAgent.search("safari");
			end = userAgent.search("platform") - 1;
			ver = userAgent.slice(start, end).trim();
			o = ver;
		} else if (userAgent.indexOf("firefox") != -1) {
			start = userAgent.search("firefox");
			end = userAgent.search("platform") - 1;
			ver = userAgent.slice(start, end).trim();
			o = ver;
		} else if (userAgent.indexOf("opera") != -1) {
			//o = "opera";
		}
	}

	info.browser = o;
	
}

function adminMenuControll(){
	$(".main-sidemenu > li").click(function(){
		var loadFileName = $(this).attr("id");

		if(loadFileName === "analymember"){
			
			$.post("./printAnalyMember.lip", function(result){
				var json = JSON.parse(result);
				var size = json.length;
				$(".contents > div").load("view/"+tPath.getView(loadFileName), function() {
//					var addRow = "";
//					$.each(json, function(i){
//						 addRow += "<tr><td>"+(size-i)+"</td>";
//						var addCol = "";
//						var tmp = json[i];
//						for(var key in tmp){
//							addCol += "<td>"+json[i][key]+"</td>";
//						}
//						addRow += addCol+"</tr>";
//					});
//					
//					$("#membersignup-table > tbody").append(addRow);
				});
			});
		}
	});
}
// ======================================================================
function menuControll() {
	
	$(".navigator").load(tPath.getView("menu_general"), function() {
		$("li").click(function(){
			$(".contents").css({"margin-left":"20%","margin-top":"0%"});
			var loadFileName = $(this).attr("value");
			if(loadFileName === "logout"){
				logout();
				return;
			}else if(loadFileName === "myinformation"){
				loadFileName = "confirmuser";
				$(".contents").load(tPath.getView(loadFileName), function(){
					confirmuser();
				});
				return;
			}else if(loadFileName === "contentlist"){
				$.ajaxSetup({cache:false});
				$.post("../contentlist.lip",function(result){
					var json = JSON.parse(result);
					$(".contents").load(tPath.getView(loadFileName));
				});
				return;
			}else if(loadFileName === "blacklist"){
				$.ajaxSetup({cache:false});
				$.post("../blacklist.lip",function(){
					$(".contents").load(tPath.getView(loadFileName));
				});
				return;
			}
			$(".contents").load(tPath.getView(loadFileName));
		});
		
//		$("ul").click(function(){
//			var loadFileName2 = $(this).attr("value");
//			$(".contents").load(tPath.getView(loadFileName2));
//		})
	});

	 // 관리자 계정으로 로그인 했을 경우
	 // 일반 로그인에서 결과가 admin 인 경우 해당
//	 $("#adminBtn").click(function(){
//	 if($(this).text() == '관리자'){
//	 $(".navigator").load("./util/menu_admin.jsp");
//	 $(this).text('일반');
//	 }else{
//	 $(".navigator").load("./util/menu_general.jsp", function() {
//	 });
//	 $(this).text('관리자');
//	 }
//
//	 });
}

function headerControll() {
	$(".glyphicon-search").click(function() {
		$(".search-box").toggle();
	});

	$(".right .glyphicon:last-child").click(function() {
		$(this).toggleClass("glyphicon-menu-hamburger");
		$(".navigator").toggle(500);
	});
}

//function goToMain() {
//	location.href = tPath.getBasePath();
//}

var cateacclog = {
		
}

function pathContainer() {
	var basePath = "./";
	var viewPath = 
	[ 
	  {
		folder : "util/",
		chat : "chat",
		timer : "timer",
		menu_general : "menu_general",
		menu_admin : "menu_admin",
		graph_1 : "graph_1",
		confirmuser : "confirmuser"
	  },
	  {
		folder : "person/",
		login : "login",
		signup : "signup",
		agree: "agree",
		find: "find",
		contentlist : "contentlist",
		blacklist : "blacklist",
		myinformation : "myinformation", 
		userout : "userout"
	  },
	  {
		folder : "torron/",
		list : "list",
		create : "create",
		room : "room"
	  },
	  {
		  folder : "surpport/",
		  introduce : "introduce",
		  customer : "customer"
	  },
	  {
		  folder:"admin/",
		  analysiteuse : "analy_siteuse",
		  analymember : "analy_memberstate",
		  analypattern : "analy_pattern",
		  analyroom : "analy_room",
		  roomdetail : "room_detail"
	  }
	  ];

	var pathObj = {
		view : "view",
		js : "js",
		css : "css",
		getView : function(fileName) {

			for (var i = 0; i < viewPath.length; i++) {
				var obj = viewPath[i]
				if (obj.hasOwnProperty(fileName)) {
					 // alert("p : "+obj.folder + obj[fileName]);
					return obj.folder + obj[fileName]+".jsp";
				}
			}
		}
	}

	return {
		getView : function(fileName) {
			return pathObj.getView(fileName);
		},
		goToMain : function() {
			location.href = basePath;
			$(".contents").css({"margin-left":"20%","margin-top":"10%"});
		}
	}
}
