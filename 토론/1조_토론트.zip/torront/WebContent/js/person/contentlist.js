$(document).ready(function(){
	listEvent();
	contentListEvent();
	
});

function listEvent() {

	$("#writeBtn").click(
			function() {
				var myWindow = window.open(tPath.getView("create"), "create",
						"width=500, height=700", "scrollbar=no", "toolbar=no");
			});
}

function contentListEvent(){
	$(".torron-list-table").click(function() {
		alert("e");
		var tr = $(this).parent().children();
		alert("t : " + $(tr[0]).text());
		$.ajax({
			url : "../rcontents.lip",
			type : "post",
			cache : false,
			data : {
				nono : $(tr[0]).text().trim()
			},
			success : function(result) {
				alert("e"+result);
				var rjson = JSON.parse(result);
				var roomcon = new Array();
				roomcon = rjson;
				$(".contents").load(tPath.getView("room"), function() {
					$(".head > label").text(roomcon[0].tsub);
					$(".t_contents > label").text(roomcon[0].tcon);
				});
			}
		});
	});
}

function addRoom(data) {

	var newTr = "<tr>";
	var newTd = "";

	for (var i = 0; i < 5; i++) {
		alert("d : "+data);
		var addData = addTableData(i, data);
		newTd += "<td align='center'>" + addData.value
				+ "</td>";
	}

	newTr += newTd + "</tr>";
	alert("d2 : " + newTr);

	$("#t_listTable").append(newTr);
}

function addTableData(idx, data) {
	var addData = {
		id : "",
		value : ""
	}

	switch (idx) {
	case 0:
		addData.id = "no" + idx;
		addData.value = idx;
		break;
	case 1:
		addData.id = "sub" + idx;
		addData.value = data.subject;
		break;
	case 2:
		addData.id = "host" + idx;
		addData.value = data.host;
		break;
	case 3:
		addData.id = "date" + idx;
		addData.value = '111-111';
		break;
	case 4:
		addData.id = "n" + idx;
		addData.value = 'nnn';
		break;

	default:
		break;
	}

	return addData;
}

function boardclick() {
	// 게시판 넘버 가져온다.
var datlength=0;
var datcon = null;
	$("tr").click(function() {
//		var boardno = $(this).attr("id");
//		alert("boardno : "+boardno);
//		$.ajax({
//			url : "../rcontents.lip",
//			type : "get",
//			cache : false,
//			data : {
//				nono : boardno
//			},
//			success : function(result) {
//				$("#listmenu").text("");
//				var rjson = JSON.parse(result);
//				var roomcon = new Array();
//				
//				var list = rjson.list;
////				alert("list : "+list.length);
////				for(var i=0; i<list.length; i++){
////					for(var key in list[i]){
////						alert("key : "+key+", v : "+list[i][key]);
////					}
////				}
//				var datlist = rjson.datlist;
////				alert("dat : "+datlist.length);
////				for(var i=0; i<datlist.length; i++){
////					for(var key in datlist[i]){
////						alert("key : "+key+", v : "+datlist[i][key]);
////					}
////				}
//				
//				roomcon = rjson;
//				$(".contents").load(tPath.getView("room"), function() {
//					$(".head > label").text(list[0].tsub);
//					$(".t_contents > label").text(list[0].tcon);
//					$("#hidtimer").val(list[0].ttimer);
//					$(".t_host > label").text(list[0].mnic);
//					$("#boardnumber > label").text(boardno);
//					/////////////////////////////////
//					var no=0;
//					for(var i=0;i<datlist.length;i++){
//						 var ss = "<fieldset id='"+no+"'><label class ='"+no+"' id='"+datlist[i].tdatno+"'>"+datlist[i].tdatcon+"</label>&nbsp;&nbsp;<button class='ox' id='"+no+"'>X</button><br/><button class='singo' id='sin"+no+"'>신고하기</button></fieldset>";
//							$("#c3").append(ss);
//							no++;
//					}
//					
//					$(".ox").click(function(){
//						var cno = $(this).attr("id");
//						alert(cno);
//						
//						//댓글삭제 유효성해야함.
//						var delcon = $("label[class='"+cno+"']").attr("id");
//						$.ajax({
//							url:"../datupdate.lip",
//							type:"get",
//							data:{delcontents:delcon},
//							cache:false,
//							success:function(result){
//								alert(result);
//								$("fieldset[id='"+cno+"']").remove();
//							}//function
//						})//ajax
//					
//					});
//						////////
//					//마감입니다. 로 변경하는 부분.
//					var boardnum = $("#boardnumber > label").text();
//					$.ajax({
//						url:"../tingupdate.lip",
//						type:"get",
//						data:{boardno:boardnum},
//						success:function(){
//							
//						}
//					})//ajax
//				});//room load
//				
//				
//				
//			}
//		});
//			
//		
//	});
//	// 게시판 리스트 호버.
//	$("td > label").hover(function() {
//		$(this).css("color", "red");
//	}, function() {
//		$(this).css("color", "black");
	});

}// 보드 리스트 액션 관리
