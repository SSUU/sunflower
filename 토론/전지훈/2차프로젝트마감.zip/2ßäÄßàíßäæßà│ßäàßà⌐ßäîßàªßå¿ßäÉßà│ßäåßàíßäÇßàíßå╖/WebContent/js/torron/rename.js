$(document).ready(function(){
	
	namecall();
	reurl();
	endtorron();
	
});
// 정호 토론마감하기 버튼 클릭
function endtorron(){
	$("#endtorron").click(function(){
		alert("왓다.");
		var bono = $("#bnumber > label").text();
		alert(bono);
		$.ajax({
			url : "../endtorron.lip",
			type : "get",
			data : {tno : bono,
					success : function(result){
						if(result == 1){
							alert("마감에 성공하였습니다.");
						}else if(result == 0){
							alert("이미 마감되었습니다.");
						}
					}
			}
		})
	});
}

// 정호 메인이랑 내용 가져오는 부분 20151015
function namecall(){
	$("#complete").click(function(){
		var main = $("#main").val();
		var sub = $("#sub").val();
		var bono = $("#bnumber > label").text();
		if(main.trim() == null || main.trim() == ""){
			alert("주제를 입력해주세요");
			return;
		}else if(sub.trim() == null || sub.trim() == ""){
			alert("내용을 입력해주세요");
	
		}else{
		
			$.ajax({
				url : "../mainsub.lip",
				type : "get",	
				data : {main : main,
						sub : sub,
						tno : bono
				},
				success:function(){
					alert(main);
					alert(sub);
					alert("내용이 수정되었습니다.");
					$(".contents").load(tPath.getView("list"));
				}
			
			})//ajax
		}
	});//수정완료 클릭시.
	
}
// 정호 url 바꾸는 부분 20151015
function reurl(){
	$("#relist").click(function(){
		$(".contents").load(tPath.getView("list"));
	});
}

	

