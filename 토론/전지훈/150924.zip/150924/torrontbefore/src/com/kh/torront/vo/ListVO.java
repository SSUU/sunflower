package com.kh.torront.vo;

public class ListVO {
	
	private String memail;
	private String tsub;
	private String tcon;
	private String ting;
	private String tfinish;
	private String cateno;
	
	
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getTsub() {
		return tsub;
	}
	public void setTsub(String tsub) {
		this.tsub = tsub;
	}
	public String getTcon() {
		return tcon;
	}
	public void setTcon(String tcon) {
		this.tcon = tcon;
	}
	public String getTing() {
		return ting;
	}
	public void setTing(String ting) {
		this.ting = ting;
	}
	public String getTfinish() {
		return tfinish;
	}
	public void setTfinish(String tfinish) {
		this.tfinish = tfinish;
	}
	public String getCateno() {
		return cateno;
	}
	public void setCateno(String cateno) {
		this.cateno = cateno;
	}
	
	
}