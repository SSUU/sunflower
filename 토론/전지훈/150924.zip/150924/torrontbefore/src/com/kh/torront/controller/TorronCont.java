package com.kh.torront.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.kh.torront.vo.ListVO;
import com.kh.torront.vo.Naljja;


@Controller
public class TorronCont {
	
	@Autowired
	SqlMapClientTemplate sqlMapClientTemplate;
	
	@RequestMapping("view/nalja.lip")
	public void nalja(Naljja nal,HttpServletRequest request){
		//System.out.println(nal.getNalja());
		String nalja = request.getParameter("nalja");
		String rdo = request.getParameter("tfinish");
		System.out.println(nalja);
		System.out.println(rdo);
		System.out.println(nal.getNalja());
		System.out.println(nal.getTfinish());
//		sqlMapClientTemplate.insert("naljja.insert",nal);
	}//
	
	@RequestMapping("view/torron/tcreate.lip")
	public void create(HttpServletRequest request,ListVO lvo){
		System.out.println("���� : "+lvo.getTsub());
		//����
		System.out.println("���� : "+lvo.getTcon());
		//����
		System.out.println("ī�װ��� : "+lvo.getCateno());
		String cate = lvo.getCateno();
		
		if(cate.equals("pol")){
			cate = "1";
		}else if(cate.equals("spo")){
			cate = "2";
		}else if(cate.equals("love")){
			cate = "3";
		}
		System.out.println(cate);
		//ī�װ���
		String a = lvo.getCateno();
		System.out.println("�����ð� : "+lvo.getTfinish());
		//�����ð�
		//db �۾�
		System.out.println(lvo);
		System.out.println("s : "+sqlMapClientTemplate);
		sqlMapClientTemplate.insert("torron.insert",lvo);
		
		
		
	}//
}
