$(document).ready(function(){
	$("#confirm").click(function(){
		alert("1");
	});
});