//신고 버튼 누를시 동작
var scontents = "";
$(document).ready(function(){
	//신고 확인키
	$("#con").click(function(){
		alert("신고 접수 되었습니다.");
		alert("신고내용 :"+opener.window.scontents);
		window.close();
	});
	//신고 취소키
	$("#can").click(function(){
		window.close();
	});
});
//채팅 창 관련
$(document).ready(function(){
	
	var no=0;
	//댓글 쓰기 버튼 누를시,
	$(".tbtn").click(function(){
		var txt = $(".ta").val();
		var ttt = txt.trim();
		//댓글 유효성
		if(ttt == "" || txt == ""){
			alert("댓글 내용 입력 부탁드립니다.");
		}else{
			$(".ta").val("");
			var ss = "<fieldset id='"+no+"'><label id='"+no+"'>"+txt+"</label>&nbsp;&nbsp;<button class='ox' id='"+no+"'>X</button><br/><button class='singo' id='sin"+no+"'>신고하기</button></fieldset>";
			$("#c3").append(ss);
			$("button[id='"+no+"']").focus();
			no++;
		}
		//신고버튼 누를시 창 사이즈
		$(".singo").click(function(){
			var singo = $(this).attr("id");
			var sno = $(this).parent().attr("id");
			scontents = $("label[id='"+sno+"']").text();;
			window.open("./singo.jsp","singo","width=220, height=120");
		});	//.singo버튼
		
		//댓글지우기
		$(".ox").click(function(){
			var xbtn = $(this).attr("id");
			$(this).parent().remove();
		});			//x버튼
	});				//.tbtn버튼
});


function toto(){
	var obj = document.getElementById('ttotal');
	var tt = "총 :"+(total-2)+"명 중, 찬성 :"+(chan-1)+"명/ 반대"+(ban-1)+"명";
	obj.innerHTML = tt;
}

// graph
function chattingGraphInit(){
	//찬성 버튼 호버
	$("#chan").hover(function(){
		$(this).css("background-color","white");
		$(this).css("color","black");
	},function(){
		$(this).css("background-color","blue");
		$(this).css("color","white");
	});
	//반대 버튼 호버
	$("#ban").hover(function(){
		$(this).css("background-color","white");
		$(this).css("color","black");
	},function(){
		$(this).css("background-color","red");
		$(this).css("color","white");
	});
	
	//찬성 /반대 버튼 클릭시,
	$("button").click(function(){
		var vote = $(this).text();
		if(vote == "찬성"){
			chan+=1;
			total+=1;
			setInterval(drawChart(), 1000);
			setInterval(toto(), 1000);
		}else if(vote == "반대"){
			ban+=1;
			total+=1;
			setInterval(drawChart(), 1000);
			setInterval(toto(), 1000);
		}//else
	}); // 찬반 버튼 클
}


// 시간 세기
function show(){
	var test = new Date();
	var test1 = new Date("Sep 14 2015 02:45:52");
	
	var month =  test.getMonth()+1;
	var day =  test.getDate();
	var hour = test.getHours();
	var minutes = test.getMinutes();
	var second = test.getSeconds();
	var hour1 = 23-hour;
	var minutes1 = 59-minutes;
	//var minutes1 = 0;
	var second1 = 59-second;
	
		var tt = "<div>남은 시간 : ";
		//tt+="<b>"+month+"</b>월";
		//tt+="<b>"+day1"</b>일";
		tt+="<b>"+hour1+"</b>시간";
		tt+="<b>"+minutes1+"</b>분";
		tt+="<b>"+second1+"</b>초 남았습니다.</div>";
		
		var obj = document.getElementById('datetest');
		obj.innerHTML = tt;
		
	if(second1 == 0 && minutes1 == 0){
		obj.innerHTML = "남은시간 : 종료되었습니다.";
		clearInterval(jojo);
	}
	
}//show 
var jojo = 0;
$(document).ready(function(){
	jojo = setInterval("show()", 1000);
	
});