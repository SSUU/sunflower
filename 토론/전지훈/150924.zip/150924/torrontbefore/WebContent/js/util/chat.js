$(document).ready(function(){
	
	chatEvent();
	
	//신고 버튼 누를시 동작
	
});

function chatEvent(){
	
	//채팅 창 관련
		
		var no=0;
		//댓글 쓰기 버튼 누를시,
		$(".tbtn").click(function(){
			var txt = $(".ta").val();
			var ttt = txt.trim();
			//댓글 유효성
			if(ttt == "" || txt == ""){
				alert("댓글 내용 입력 부탁드립니다.");
			}else{
				$(".ta").val("");
				var ss = "<fieldset id='"+no+"'><label id='"+no+"'>"+txt+"</label>&nbsp;&nbsp;<button class='ox' id='"+no+"'>X</button><br/><button class='singo' id='sin"+no+"'>신고하기</button></fieldset>";
				$("#c3").append(ss);
				$("button[id='"+no+"']").focus();
				no++;
			}
			//신고버튼 누를시 창 사이즈
			$(".singo").click(function(){
				var singo = $(this).attr("id");
				var sno = $(this).parent().attr("id");
				scontents = $("label[id='"+sno+"']").text();;
				window.open("../view/torron/singo.jsp","singo","width=220, height=120");
			});	//.singo버튼
			
			//댓글지우기
			$(".ox").click(function(){
				var xbtn = $(this).attr("id");
				$(this).parent().remove();
			});			//x버튼
		});				//.tbtn버튼
	
	
	
//	var no=0;
//	$(".tbtn").click(function(){
//		var txt = $(".ta").val();
//		var ss = "<fieldset id='"+no+"'>"+txt+"<button id='"+no+"'>X</button></fieldset>";
//		$("#c3").append(ss);
//		$("button[id='"+no+"']").focus();
//		no++;
//	});
	
}


