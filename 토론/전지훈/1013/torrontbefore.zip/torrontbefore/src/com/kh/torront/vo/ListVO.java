package com.kh.torront.vo;

public class ListVO {
	private String tno;
	private String tsub;
	private String tcon;
	private String ting;
	private String tfinish;
	private String cateno;
	private String scrap;
	private String memail;
	private String tdate;
	private String mnic;
	private String ttimer;
	
	public String getTtimer() {
		return ttimer;
	}
	public void setTtimer(String ttimer) {
		this.ttimer = ttimer;
	}
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getMnic() {
		return mnic;
	}
	public void setMnic(String mnic) {
		this.mnic = mnic;
	}
	public String getTsub() {
		return tsub;
	}
	public void setTsub(String tsub) {
		this.tsub = tsub;
	}
	public String getTcon() {
		return tcon;
	}
	public void setTcon(String tcon) {
		this.tcon = tcon;
	}
	public String getTing() {
		return ting;
	}
	public void setTing(String ting) {
		this.ting = ting;
	}
	public String getTfinish() {
		return tfinish;
	}
	public void setTfinish(String tfinish) {
		this.tfinish = tfinish;
	}
	public String getCateno() {
		return cateno;
	}
	public void setCateno(String cateno) {
		this.cateno = cateno;
	}
	public String getScrap() {
		return scrap;
	}
	public void setScrap(String scrap) {
		this.scrap = scrap;
	}
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	
}
