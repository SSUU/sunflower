package com.kh.torront.vo;

public class DatgleVO {

	private String tdatno;	
	private String tno;
	private String tdatuser;	
	private String tdatcon;	
	private String tdatcnt;	
	private String tdate;
	private String mnic;
	
	
	public String getMnic() {
		return mnic;
	}
	public void setMnic(String mnic) {
		this.mnic = mnic;
	}
	public String getTdatno() {
		return tdatno;
	}
	public void setTdatno(String tdatno) {
		this.tdatno = tdatno;
	}
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getTdatuser() {
		return tdatuser;
	}
	public void setTdatuser(String tdatuser) {
		this.tdatuser = tdatuser;
	}
	public String getTdatcon() {
		return tdatcon;
	}
	public void setTdatcon(String tdatcon) {
		this.tdatcon = tdatcon;
	}
	public String getTdatcnt() {
		return tdatcnt;
	}
	public void setTdatcnt(String tdatcnt) {
		this.tdatcnt = tdatcnt;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	
	
	
	}
