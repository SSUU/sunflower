package com.kh.torront.vo;

public class DatgleVO {
	
	//��������� ���� vo
	private String tdatno;	
	private String tno;
	private String tdatuser;	
	private String tdatcon;	
	private String tdatcnt;	
	private String tdate;
	private String mnic;
	/////////��� �Ű� vo
	private String treyou; 
	private String tredate; 
	
	
	public String getTreyou() {
		return treyou;
	}
	public void setTreyou(String treyou) {
		this.treyou = treyou;
	}
	public String getTredate() {
		return tredate;
	}
	public void setTredate(String tredate) {
		this.tredate = tredate;
	}
	public String getMnic() {
		return mnic;
	}
	public void setMnic(String mnic) {
		this.mnic = mnic;
	}
	public String getTdatno() {
		return tdatno;
	}
	public void setTdatno(String tdatno) {
		this.tdatno = tdatno;
	}
	public String getTno() {
		return tno;
	}
	public void setTno(String tno) {
		this.tno = tno;
	}
	public String getTdatuser() {
		return tdatuser;
	}
	public void setTdatuser(String tdatuser) {
		this.tdatuser = tdatuser;
	}
	public String getTdatcon() {
		return tdatcon;
	}
	public void setTdatcon(String tdatcon) {
		this.tdatcon = tdatcon;
	}
	public String getTdatcnt() {
		return tdatcnt;
	}
	public void setTdatcnt(String tdatcnt) {
		this.tdatcnt = tdatcnt;
	}
	public String getTdate() {
		return tdate;
	}
	public void setTdate(String tdate) {
		this.tdate = tdate;
	}
	
	
	
	}
