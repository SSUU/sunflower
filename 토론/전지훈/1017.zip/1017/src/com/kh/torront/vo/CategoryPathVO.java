package com.kh.torront.vo;

public class CategoryPathVO {

	private String cpno;
	private String cpname;
	private String cppath;
	private String cpcnt;
	
	public String getCpno() {
		return cpno;
	}
	public void setCpno(String cpno) {
		this.cpno = cpno;
	}
	public String getCpname() {
		return cpname;
	}
	public void setCpname(String cpname) {
		this.cpname = cpname;
	}
	public String getCppath() {
		return cppath;
	}
	public void setCppath(String cppath) {
		this.cppath = cppath;
	}
	public String getCpcnt() {
		return cpcnt;
	}
	public void setCpcnt(String cpcnt) {
		this.cpcnt = cpcnt;
	}

}
