$(document).ready(function() {
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// session 을 통한 로그인 유효성 검사
	// li 태그 로그인 text를 마이페이지로 변경
	menuControll();
	headerControll();
	
});
var tPath = pathContainer();

function menuControll() {
	
	$(".navigator").load(tPath.getView("menu_general"), function() {
		$("li").click(function(){
			var loadFileName = $(this).attr("value");
			if(loadFileName == "list"){
				$.ajax({
					url : "../select.lip",
					type:"get",
					success:function(result){
						$(".contents").load(tPath.getView(loadFileName),function(){
							var tata = JSON.parse(result);
							var a = new Array();
								 a  = tata;
							
							var tableTr = "<tr>";
							for(var i = 0;i<tata.length;i++){
								tableTr+="<td align='center'>"+a[i].tno+"</td>" +
										"<td align='center'><label id='"+a[i].tno+"'>"+a[i].tsub+"</label></td>" +
										"<td align='center'>"+a[i].mnic+"</td>" +
										"<td align='center'>"+a[i].tdate.substring(0,10)+"</td>" +
										"<td align='center'>"+a[i].ting+"</td></tr>" ;
							}
							$("#t_listTable").append(tableTr);
							boardclick();
							
						});
						
					} //success!
					});//ajax 
			}//if
		});//li click
	});//load

	 // 관리자 계정으로 로그인 했을 경우
	 // 일반 로그인에서 결과가 admin 인 경우 해당
//	 $("#adminBtn").click(function(){
//	 if($(this).text() == '관리자'){
//	 $(".navigator").load("./util/menu_admin.jsp");
//	 $(this).text('일반');
//	 }else{
//	 $(".navigator").load("./util/menu_general.jsp", function() {
//	 });
//	 $(this).text('관리자');
//	 }
//
//	 });
}

function headerControll() {
	$(".glyphicon-search").click(function() {
		$(".search-box").toggle();
	});

	$(".right .glyphicon:last-child").click(function() {
		$(this).toggleClass("glyphicon-menu-hamburger");
		$(".navigator").toggle(500);
	});
}

//function goToMain() {
//	location.href = tPath.getBasePath();
//}

//보드 리스트 액션 관리
function boardclick(){
	//게시판 넘버 가져온다.
	$("td > label").click(function(){
		alert($(this).attr("id"));
	});
	//게시판 리스트 호버.
	$("td > label").hover(function(){
		$(this).css("color","red");
	},function(){
		$(this).css("color","black");
	});
}//보드 리스트 액션 관리

function pathContainer() {
	var basePath = "./";
	var viewPath = 
	[ 
	  {
		folder : "util/",
		chat : "chat",
		timer : "timer",
		menu_general : "menu_general",
		menu_admin : "menu_admin",
		graph_1 : "graph_1"
	  },
	  {
		folder : "person/",
		login : "login",
		signup : "signup",
		agree: "agree",
		find: "find"
	  },
	  {
		folder : "torron/",
		list : "list",
		create : "create",
		room : "room"
	  },
	  {
		  folder : "surpport/",
		  introduce : "introduce",
		  customer : "customer"
	  }
	  ];

	var pathObj = {
		view : "view",
		js : "js",
		css : "css",
		getView : function(fileName) {

			for (var i = 0; i < viewPath.length; i++) {
				var obj = viewPath[i]
				if (obj.hasOwnProperty(fileName)) {
					// alert("p : "+obj.folder + obj[fileName]);
					return obj.folder + obj[fileName]+".jsp";
				}
			}
		}
	}

	return {
		getView : function(fileName) {
			return pathObj.getView(fileName);
		},
		goToMain : function() {
			location.href = basePath;
		}
	}
}
