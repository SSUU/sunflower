package com.kh.torront.vo;

public class MemVO {
	
	private String memail;
	private String mpw;
	private String mname;
	private String mnic;
	private String mdate;
	private String mgender;
	private String mfbuse;
	
	public String getMemail() {
		return memail;
	}
	public void setMemail(String memail) {
		this.memail = memail;
	}
	public String getMpw() {
		return mpw;
	}
	public void setMpw(String mpw) {
		this.mpw = mpw;
	}
	public String getMname() {
		return mname;
	}
	public void setMname(String mname) {
		this.mname = mname;
	}
	public String getMnic() {
		return mnic;
	}
	public void setMnic(String mnic) {
		this.mnic = mnic;
	}
	public String getMdate() {
		return mdate;
	}
	public void setMdate(String mdate) {
		this.mdate = mdate;
	}
	public String getMgender() {
		return mgender;
	}
	public void setMgender(String mgender) {
		this.mgender = mgender;
	}
	public String getMfbuse() {
		return mfbuse;
	}
	public void setMfbuse(String mfbuse) {
		this.mfbuse = mfbuse;
	}
	
}

