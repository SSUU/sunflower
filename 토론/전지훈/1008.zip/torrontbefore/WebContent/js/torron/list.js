$(document).ready(
		function() {

			$.ajax({
				url : "../select.lip",
				type : "get",
				success : function(result) {
					var tata = JSON.parse(result);
					var a = new Array();
					a = tata;

					if (tata.length > 0) {
						var tableTr = "<tr>";
						for (var i = 0; i < tata.length; i++) {
							tableTr += "<td align='center'>" + a[i].tno
									+ "</td>"
									+ "<td align='center'><label id='"
									+ a[i].tno + "'>" + a[i].tsub
									+ "</label></td>" + "<td align='center'>"
									+ a[i].mnic + "</td>"
									+ "<td align='center'>"
									+ a[i].tdate.substring(0, 10) + "</td>"
									+ "<td align='center'>" + a[i].ting
									+ "</td></tr>";
						}
						$("#t_listTable").append(tableTr);
					}// if

					boardclick();
					listEvent();

				} // success!
			});// ajax
		});
var dlistno=0;
//보드 리스트 클릭했을시,
function boardclick() {
	// 게시판 넘버 가져온다.
	$("td > label").click(function() {
		var boardno = $(this).attr("id");
		$.ajax({
			url : "../rcontents.lip",
			type : "get",
			cache : false,
			data : {
				nono : boardno
			},
			success : function(result) {
				var rjson = JSON.parse(result);
				var roomcon = new Array();
				roomcon = rjson;
				$(".contents").load(tPath.getView("room"), function() {
					$(".head > label").text(roomcon[0].tsub);
					$(".t_contents > label").text(roomcon[0].tcon);
					/////////////////////////////////
//					for(var i= 2;i<rjson.length;i++){
//						var ss = "<fieldset id='"+dlistno+"'><label id='"+dlistno+"'>"+txt+"</label>&nbsp;&nbsp;<button class='ox' id='"+dlistno+"'>X</button><br/><button class='singo' id='sin"+dlistno+"'>신고하기</button></fieldset>";
//						$("#c3").append(ss);
//						dlistno++;
//					}
					alert(roomcon.length+"ssss");
				});

			}
		});

	});
	// 게시판 리스트 호버.
	$("td > label").hover(function() {
		$(this).css("color", "red");
	}, function() {
		$(this).css("color", "black");
	});

}// 보드 리스트 액션 관리

function listEvent() {
	$("#write").click(
			function() {
				var myWindow = window.open(tPath.getView("create"), "create",
						"width=500, height=700", "scrollbar=no", "toolbar=no");
			});
}

function addTableData(idx, data) {
	var addData = {
		id : "",
		value : ""
	}

	switch (idx) {
	case 0:
		addData.id = "no" + idx;
		addData.value = idx;
		break;
	case 1:
		addData.id = "sub" + idx;
		addData.value = data.subject;
		break;
	case 2:
		addData.id = "host" + idx;
		addData.value = data.host;
		break;
	case 3:
		addData.id = "date" + idx;
		addData.value = '111-111';
		break;
	case 4:
		addData.id = "n" + idx;
		addData.value = 'nnn';
		break;

	default:
		break;
	}

	return addData;
}
